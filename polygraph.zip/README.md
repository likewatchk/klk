# polygraph

[![Build Status](https://travis-ci.org/polygraph-python/polygraph.svg?branch=master)](https://travis-ci.org/polygraph-python/polygraph)

A Python GraphQL library with a focus on flexibility and extensibility.
